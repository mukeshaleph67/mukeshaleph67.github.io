import UIKit
import MessageUI

class MailComposerUtil:  NSObject, MFMailComposeViewControllerDelegate {
    var viewcontroller: UIViewController?
    func sendTroubleShootLogs(viewController: UIViewController) {
        viewcontroller = viewController
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self as MFMailComposeViewControllerDelegate
            let toEmailId = "Shabeen.AbdSalam@UOBgroup.com"
            mail.setToRecipients([toEmailId])
            mail.setSubject("TMRW " + "Singapore" + "- iOS - troubleshooting logs - info")
            let messageBody1 = "<p>Hello, </p>" +
                "<p>I am experiencing problem with TMRW app</p>" +
            "<p>Please find the attached trouble logs.</p>"
            let messageBody2 = "<p>Troubleshoot ID:" + "1000"  + " </p>"
                + "<p>Device ID:" + "ID0000000111111" + "</p>"
            let messageBody3 = "<p>OS version:" + UIDevice.current.systemVersion + "</p>"
            let messageBody4 = "<p>App Version: " + ("14.0") + "</p>"
            mail.setMessageBody(messageBody1 + messageBody2 + messageBody3 + messageBody4, isHTML: true)
            
            let documentDirectory = FileManager.SearchPathDirectory.documentDirectory
            let userDomainMask = FileManager.SearchPathDomainMask.userDomainMask
            let paths = NSSearchPathForDirectoriesInDomains(documentDirectory, userDomainMask, true)
            
            if let dirPath = paths.first {
                let vtapURL = URL(fileURLWithPath: dirPath).appendingPathComponent("vtap.db")
                let vguardURL = URL(fileURLWithPath: dirPath).appendingPathComponent("vguard.db")
                let filepathList: [URL] = [vtapURL, vguardURL]
                for urlPath in filepathList {
                    let path = urlPath.path
                    if let fileData = NSData(contentsOfFile: path) {
                        mail.addAttachmentData(fileData as Data, mimeType: "application/txt", fileName: urlPath.lastPathComponent)
                    }
                }
            }
            viewController.present(mail, animated: true)
        } else {
          showAlert()
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        viewcontroller?.view.backgroundColor = .yellow
        controller.dismiss(animated: true)
        self.showAlert()
    }
    func showAlert() {
        let alert = UIAlertController(title: "Success", message: "Message", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        viewcontroller?.present(alert, animated: true, completion: nil)
    }
}
