//
//  ViewController.swift
//  MerchantApp
//
//  Created by venvehuob on 19/1/21.
//  Copyright © 2021 vermamukesh. All rights reserved.
//

import UIKit

extension URL {
    func getQueryStringParameter(param: String) -> String? {
        guard let url = URLComponents(string: self.absoluteString) else { return nil }
        return url.queryItems?.first(where: { $0.name == param })?.value
    }
}

class ViewController: UIViewController {
static let notificationName = "handleUrl"
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(notify(object:)), name: NSNotification.Name(rawValue: "handleUrl"), object: nil)
    }
    @IBAction func btnOpenUOBTapped(_ sender: Any) {
       UIApplication.shared.open(URL.init(string: "https://alephdemo.page.link/merchant")!)
    }
    @IBAction func btnOpenURLTapped(_ sender: Any) {
        UIApplication.shared.open(URL.init(string: "https://alephdemo.page.link?callback=https://alephdemo.page.link/m6767")!)
         // UIApplication.shared.open(URL.init(string: "https://alephdemo.page.link?curPage=2")!)
    }
    @IBAction func btnHtmlTapped(_ sender: Any) {
        //UIApplication.shared.open(URL.init(string: "https://merchantwebsite.page.link/home")!)
        //UIApplication.shared.open(URL.init(string: "https://merchantweb.htmlsave.net/")!)
        
        UIApplication.shared.open(URL.init(string: "https://mukeshaleph67.github.io/test2.html")!)
    }

    @objc func notify(object: Notification) {
        self.navigationController?.popToRootViewController(animated: true)
        if let userInfo = object.userInfo, let url = userInfo["url"] as? URL {
            self.label.text = url.absoluteString
        } else {
            self.label.text = nil
        }
        let alert = UIAlertController(title: "Success", message: "Message", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

