//
//  WebViewController.swift
//  UniversalLinkDemo
//
//  Created by venvehuob on 19/1/21.
//  Copyright © 2021 vermamukesh. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController, WKNavigationDelegate {
    @IBOutlet weak var webView: WKWebView!
    var isViewDidAppear = false
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.navigationDelegate = self
        let url = URL(string: "https://mukeshaleph67.github.io/test2.html")!
        //let url = URL(string: "https://alephdemo.page.link/m6767")!
        webView.load(URLRequest(url: url))
        webView.allowsBackForwardNavigationGestures = true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url {
            print(url)
            if let linkUrl = url.getQueryStringParameter(param: "link"), let callBackUrl = URL(string: linkUrl)?.getQueryStringParameter(param: "callback") {
                if isViewDidAppear {
                    UIApplication.shared.open( URL.init(string: callBackUrl)!)
                }
                decisionHandler(.allow)
                return
            } else if let _ = url.getQueryStringParameter(param: "callback") {
                if isViewDidAppear {
                    UIApplication.shared.open( URL.init(string: "https://www.singtel.com")!)
                }
                decisionHandler(.cancel)
                return
            }
        }
        decisionHandler(.allow)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("finished loading url =", webView.url ?? "")
        isViewDidAppear = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
