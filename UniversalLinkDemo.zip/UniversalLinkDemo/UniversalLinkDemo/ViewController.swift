//
//  ViewController.swift
//  UniversalLinkDemo
//
//  Created by venvehuob on 14/1/21.
//  Copyright © 2021 vermamukesh. All rights reserved.
//

import UIKit

extension URL {
    func getQueryStringParameter(param: String) -> String? {
        guard let url = URLComponents(string: self.absoluteString) else { return nil }
        return url.queryItems?.first(where: { $0.name == param })?.value
    }
}

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    
    static let notificationName = "handleUrl"
    
    @IBOutlet weak var btnOpenUrl: UIButton!
    var webUrlToOpen: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(notify(object:)), name: NSNotification.Name(rawValue: "handleUrl"), object: nil)
        self.btnOpenUrl.isEnabled = false
        self.btnOpenUrl.alpha = 0.5
    }
    
    @IBAction func btnOpenUrlTapped(_ sender: Any) {
        guard let url = webUrlToOpen else {
            return
        }
        UIApplication.shared.open(url)
    }
    
    @objc func notify(object: Notification) {
        if let userInfo = object.userInfo, let url = userInfo["url"] as? URL, let callBackUrl = url.getQueryStringParameter(param: "callback") {
            if callBackUrl == "https://mukeshaleph67.github.io/test2.html" || callBackUrl == "https://mukeshaleph67.github.io/test2.html" {
                self.btnOpenUrl.setTitle("Done", for: UIControl.State.normal)
                //UIApplication.shared.open( URL.init(string: "https://www.uob.com/")!)
            }
            self.label.text = url.absoluteString
            self.webUrlToOpen = URL(string: callBackUrl)!
            self.btnOpenUrl.isEnabled = true
            self.btnOpenUrl.alpha = 1.0
        } else {
            self.label.text = nil
        }
    }
    
}

